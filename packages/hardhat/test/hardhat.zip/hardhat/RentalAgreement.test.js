const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("RentalAgreement", function () {
    let RentalAgreement, rentalAgreement, MockToken, token, MockEscrow, escrow, MockInspection, inspection, MockDisputeResolution, disputeResolution, MockSocialFi, socialFi, MockAccessRestriction, accessRestriction;
    let owner, admin, rentee, renter, user1;

    beforeEach(async function () {
        // Deploy the mock contracts
        MockToken = await ethers.getContractFactory("MockToken");
        token = await MockToken.deploy("MockToken", "MTK", 18, ethers.utils.parseEther("1000"));
        await token.deployed();

        MockEscrow = await ethers.getContractFactory("MockEscrow");
        escrow = await MockEscrow.deploy();
        await escrow.deployed();

        MockInspection = await ethers.getContractFactory("MockInspection");
        inspection = await MockInspection.deploy();
        await inspection.deployed();

        MockDisputeResolution = await ethers.getContractFactory("MockDisputeResolution");
        disputeResolution = await MockDisputeResolution.deploy();
        await disputeResolution.deployed();

        MockSocialFi = await ethers.getContractFactory("MockSocialFi");
        socialFi = await MockSocialFi.deploy();
        await socialFi.deployed();

        MockAccessRestriction = await ethers.getContractFactory("MockAccessRestriction");
        accessRestriction = await MockAccessRestriction.deploy();
        await accessRestriction.deployed();

        // Deploy the RentalAgreement contract
        RentalAgreement = await ethers.getContractFactory("RentalAgreement");
        [owner, admin, rentee, renter, user1] = await ethers.getSigners();
        rentalAgreement = await RentalAgreement.deploy(token.address, escrow.address, inspection.address, disputeResolution.address, socialFi.address, accessRestriction.address);
        await rentalAgreement.deployed();

        // Set up roles in the access restriction mock
        await accessRestriction.setVerifiedUser(rentee.address, true);
        await accessRestriction.setVerifiedUser(renter.address, true);
    });

    describe("Constructor", function () {
        it("should set the correct addresses for dependencies", async function () {
            const escrowAddress = await rentalAgreement.escrow();
            const inspectionAddress = await rentalAgreement.inspection();
            const disputeResolutionAddress = await rentalAgreement.disputeResolution();
            const socialFiAddress = await rentalAgreement.socialFi();
            const accessRestrictionAddress = await rentalAgreement.accessRestriction();

            expect(escrowAddress).to.equal(escrow.address);
            expect(inspectionAddress).to.equal(inspection.address);
            expect(disputeResolutionAddress).to.equal(disputeResolution.address);
            expect(socialFiAddress).to.equal(socialFi.address);
            expect(accessRestrictionAddress).to.equal(accessRestriction.address);
        });

        it("should revert if any of the dependency addresses are zero", async function () {
            await expect(
                RentalAgreement.deploy(token.address, ethers.constants.AddressZero, inspection.address, disputeResolution.address, socialFi.address, accessRestriction.address)
            ).to.be.revertedWith("InvalidAddress(\"escrow\")");
        });
    });

    describe("createAgreement", function () {
        it("should allow a verified user to create an agreement", async function () {
            await rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 100, 50);
            const agreement = await rentalAgreement.agreements(0);

            expect(agreement.rentee.userAddress).to.equal(rentee.address);
            expect(agreement.rentalPeriod).to.equal(10);
            expect(agreement.cost).to.equal(100);
            expect(agreement.deposit).to.equal(50);
            expect(agreement.status).to.equal(0); // CREATED
        });

        it("should emit an AgreementCreated event when an agreement is created", async function () {
            await expect(rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 100, 50))
                .to.emit(rentalAgreement, "AgreementCreated")
                .withArgs(1, rentee.address, renter.address);
        });

        it("should revert if the caller is not a verified user", async function () {
            await expect(rentalAgreement.connect(user1).createAgreement(renter.address, 1, 10, 100, 50))
                .to.be.revertedWith(`NotVerifiedUser("${user1.address}")`);
        });

        it("should revert if the cost, deposit, or rental period is zero", async function () {
            await expect(rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 0, 100, 50))
                .to.be.revertedWith("MustBeGraterThanZero(\"cost\")");
            await expect(rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 0, 50))
                .to.be.revertedWith("MustBeGraterThanZero(\"deposit\")");
            await expect(rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 100, 0))
                .to.be.revertedWith("MustBeGraterThanZero(\"rentalPeriod\")");
        });

        it("should revert if the asset is not active", async function () {
            // Assuming assets[1] is not active
            await expect(rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 100, 50))
                .to.be.revertedWith("AssetIsNotActive()");
        });
    });

    describe("ArrivalAgreement", function () {
        beforeEach(async function () {
            // Create an agreement first
            await rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 100, 50);
        });

        it("should allow the renter to confirm their arrival and start the agreement", async function () {
            // Fund the renter with sufficient tokens
            await token.transfer(renter.address, ethers.utils.parseEther("200"));
            await token.connect(renter).approve(rentalAgreement.address, ethers.utils.parseEther("200"));

            await rentalAgreement.connect(renter).ArrivalAgreement(0);
            const agreement = await rentalAgreement.agreements(0);

            expect(agreement.renter.userAddress).to.equal(renter.address);
            expect(agreement.status).to.equal(1); // REQUESTED
            expect(agreement.startTime).to.be.gt(0);
        });

        it("should emit an ArrivalAgreementEvent event on arrival confirmation", async function () {
            await token.transfer(renter.address, ethers.utils.parseEther("200"));
            await token.connect(renter).approve(rentalAgreement.address, ethers.utils.parseEther("200"));

            await expect(rentalAgreement.connect(renter).ArrivalAgreement(0))
                .to.emit(rentalAgreement, "ArrivalAgreementEvent")
                .withArgs(0, rentee.address, renter.address, anyTimestamp);
        });

        it("should revert if the agreement is not in the correct status", async function () {
            await rentalAgreement.connect(renter).ArrivalAgreement(0);

            // Try confirming arrival again
            await expect(rentalAgreement.connect(renter).ArrivalAgreement(0))
                .to.be.revertedWith("InvalidAgreement()");
        });

        it("should revert if the renter has insufficient balance", async function () {
            await expect(rentalAgreement.connect(renter).ArrivalAgreement(0))
                .to.be.revertedWith("InsufficientBalance");
        });

        it("should revert if the asset is no longer active", async function () {
            // Assuming we deactivate the asset here
            await rentalAgreement.connect(owner).deactivateAsset(1); // Assuming deactivateAsset is a function in your contract

            await expect(rentalAgreement.connect(renter).ArrivalAgreement(0))
                .to.be.revertedWith("AssetIsNotActive()");
        });
    });

    describe("completeAgreement", function () {
        beforeEach(async function () {
            // Create and start an agreement first
            await rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 100, 50);
            await token.transfer(renter.address, ethers.utils.parseEther("200"));
            await token.connect(renter).approve(rentalAgreement.address, ethers.utils.parseEther("200"));
            await rentalAgreement.connect(renter).ArrivalAgreement(0);
        });

        it("should allow either party to complete the agreement after the rental period", async function () {
            // Simulate the passage of time
            await ethers.provider.send("evm_increaseTime", [11]); // Increase time by 11 seconds (or blocks)

            await rentalAgreement.connect(rentee).completeAgreement(0);
            const agreement = await rentalAgreement.agreements(0);

            expect(agreement.status).to.equal(3); // COMPLETED
        });

        it("should emit an AgreementCompleted event on completion", async function () {
            await ethers.provider.send("evm_increaseTime", [11]); // Increase time by 11 seconds (or blocks)

            await expect(rentalAgreement.connect(rentee).completeAgreement(0))
                .to.emit(rentalAgreement, "AgreementCompleted")
                .withArgs(0);
        });

        it("should revert if the agreement is not in the STARTED status", async function () {
            // Assuming agreement[1] is in CREATED status
            await expect(rentalAgreement.connect(rentee).completeAgreement(1))
                .to.be.revertedWith("AgreementNotActive()");
        });

        it("should revert if the rental period is not over", async function () {
            await expect(rentalAgreement.connect(rentee).completeAgreement(0))
                .to.be.revertedWith("RentalPeriodNotOver");
        });

        it("should revert if the item fails inspection", async function () {
            // Assuming inspection fails for this agreement
            await inspection.setInspectionResult(0, false);

            await ethers.provider.send("evm_increaseTime", [11]); // Increase time by 11 seconds (or blocks)

            await expect(rentalAgreement.connect(rentee).completeAgreement(0))
                .to.be.revertedWith("InspectionFailed");
        });
    });

    describe("cancelAgreement", function () {
        beforeEach(async function () {
            // Create and start an agreement first
            await rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 100, 50);
            await token.transfer(renter.address, ethers.utils.parseEther("200"));
            await token.connect(renter).approve(rentalAgreement.address, ethers.utils.parseEther("200"));
            await rentalAgreement.connect(renter).ArrivalAgreement(0);
        });

        it("should allow the renter to cancel the agreement", async function () {
            await rentalAgreement.connect(renter).cancelAgreement(0);
            const agreement = await rentalAgreement.agreements(0);

            expect(agreement.status).to.equal(4); // CANCELLED
        });

        it("should emit an AgreementCancelled event on cancellation", async function () {
            await expect(rentalAgreement.connect(renter).cancelAgreement(0))
                .to.emit(rentalAgreement, "AgreementCancelled")
                .withArgs(0);
        });

        it("should revert if the agreement is not in the STARTED status", async function () {
            await rentalAgreement.connect(renter).cancelAgreement(0);

            // Try canceling again
            await expect(rentalAgreement.connect(renter).cancelAgreement(0))
                .to.be.revertedWith("AgreementNotActive()");
        });

        it("should revert if a non-renter tries to cancel the agreement", async function () {
            await expect(rentalAgreement.connect(rentee).cancelAgreement(0))
                .to.be.revertedWith("NotAuthorized()");
        });
    });

    describe("raiseDispute", function () {
        beforeEach(async function () {
            // Create and start an agreement first
            await rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 100, 50);
            await token.transfer(renter.address, ethers.utils.parseEther("200"));
            await token.connect(renter).approve(rentalAgreement.address, ethers.utils.parseEther("200"));
            await rentalAgreement.connect(renter).ArrivalAgreement(0);
        });

        it("should allow either party to raise a dispute", async function () {
            await rentalAgreement.connect(rentee).raiseDispute(0);
            const agreement = await rentalAgreement.agreements(0);

            expect(agreement.isDisputed).to.be.true;
        });

        it("should emit a DisputeRaised event when a dispute is raised", async function () {
            await expect(rentalAgreement.connect(rentee).raiseDispute(0))
                .to.emit(rentalAgreement, "DisputeRaised")
                .withArgs(0);
        });

        it("should revert if the agreement is not in the STARTED status", async function () {
            await expect(rentalAgreement.connect(rentee).raiseDispute(1))
                .to.be.revertedWith("AgreementNotActive()");
        });

        it("should revert if a non-party tries to raise a dispute", async function () {
            await expect(rentalAgreement.connect(user1).raiseDispute(0))
                .to.be.revertedWith("NotAuthorized()");
        });
    });

    describe("extendRentalPeriod", function () {
        beforeEach(async function () {
            // Create and start an agreement first
            await rentalAgreement.connect(rentee).createAgreement(renter.address, 1, 10, 100, 50);
            await token.transfer(renter.address, ethers.utils.parseEther("200"));
            await token.connect(renter).approve(rentalAgreement.address, ethers.utils.parseEther("200"));
            await rentalAgreement.connect(renter).ArrivalAgreement(0);
        });

        it("should allow the rentee to extend the rental period and update the cost", async function () {
            await rentalAgreement.connect(rentee).extendRentalPeriodRentee(0, 5, 150);
            const agreement = await rentalAgreement.agreements(0);

            expect(agreement.rentalPeriod).to.equal(15); // Original 10 + 5
            expect(agreement.cost).to.equal(150); // Updated cost
        });

        it("should emit an AgreementExtendedRentee event when the rentee extends the rental period", async function () {
            await expect(rentalAgreement.connect(rentee).extendRentalPeriodRentee(0, 5, 150))
                .to.emit(rentalAgreement, "AgreementExtendedRentee")
                .withArgs(0, 15, 150); // New rental period 15, cost 150
        });

        it("should revert if a non-rentee tries to extend the rental period", async function () {
            await expect(rentalAgreement.connect(renter).extendRentalPeriodRentee(0, 5, 150))
                .to.be.revertedWith("NotAuthorized()");
        });

        it("should allow the renter to extend the rental period without changing the cost", async function () {
            await rentalAgreement.connect(renter).extendRentalPeriodRenter(0, 5);
            const agreement = await rentalAgreement.agreements(0);

            expect(agreement.rentalPeriod).to.equal(15); // Original 10 + 5
        });

        it("should emit an AgreementExtendedRenter event when the renter extends the rental period", async function () {
            await expect(rentalAgreement.connect(renter).extendRentalPeriodRenter(0, 5))
                .to.emit(rentalAgreement, "AgreementExtendedRenter")
                .withArgs(0, 15); // New rental period 15
        });

        it("should revert if a non-renter tries to extend the rental period", async function () {
            await expect(rentalAgreement.connect(rentee).extendRentalPeriodRenter(0, 5))
                .to.be.revertedWith("NotAuthorized()");
        });

        it("should revert if the agreement is not in the STARTED status", async function () {
            await rentalAgreement.connect(rentee).cancelAgreement(0);

            await expect(rentalAgreement.connect(rentee).extendRentalPeriodRentee(0, 5, 150))
                .to.be.revertedWith("AgreementNotActive()");
            await expect(rentalAgreement.connect(renter).extendRentalPeriodRenter(0, 5))
                .to.be.revertedWith("AgreementNotActive()");
        });
    });
});